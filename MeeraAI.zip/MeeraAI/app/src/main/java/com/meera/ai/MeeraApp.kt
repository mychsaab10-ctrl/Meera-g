package com.meera.ai

import android.app.Application

class MeeraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Meera.init(this)
    }
}
