package com.meera.ai

import android.app.Application
import android.widget.Toast
import com.meera.ai.ai.Answer
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.GeminiClient
import com.meera.ai.ai.GeminiException
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import com.meera.ai.automation.Actions
import com.meera.ai.automation.Messaging
import com.meera.ai.automation.ScreenControl
import com.meera.ai.data.AppSettings
import com.meera.ai.data.MemoryRepo
import com.meera.ai.data.SecureKeyStore
import com.meera.ai.ui.ChatSession
import com.meera.ai.voice.CallController
import com.meera.ai.voice.TtsEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

/**
 * Result of a tool call. When [ask] is true the action is NOT done yet: Meera must first ask the user
 * (by voice or in chat) and the user answers "haan"/"nahi". No popup buttons are involved.
 */
data class ToolOut(val text: String, val ask: Boolean = false) {
    /** What the Gemini Live model receives as the tool result. */
    fun forLive(): String =
        if (ask) {
            "WAITING_FOR_USER_CONFIRMATION. Nothing has been done yet. Ask the user this question in their language, in your own words, then wait: \"$text\" " +
                "When the user answers, call confirm_pending with accepted=true (they said yes) or accepted=false (they said no). Never assume the answer."
        } else text
}

/** A yes/no question that Meera asked the user. [action] executes only after a clear "yes" and returns the result text. */
class Awaiting(val prompt: String, val expiresAt: Long, val action: () -> String)

/** Tiny service locator (keeps the project easy to read for beginners). */
object Meera {
    lateinit var app: Application; private set
    lateinit var keys: SecureKeyStore; private set
    lateinit var settings: AppSettings; private set
    lateinit var gemini: GeminiClient; private set
    lateinit var memory: MemoryRepo; private set
    lateinit var chat: ChatSession; private set
    lateinit var coding: ChatSession; private set
    lateinit var call: CallController; private set

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /** In-app consent switch for screen control (resets on every app start). */
    val accessGate = MutableStateFlow(false)

    /** Log shown on the Phone Automation screen. */
    val log = MutableStateFlow("")

    /** Avatar mood for Home/Chat: normal | happy | excited | sad | loving | thinking. */
    val mood = MutableStateFlow("normal")

    /** The user's latest sentence (typed or transcribed). Used to verify spoken confirmations. */
    @Volatile var lastUserText: String = ""

    @Volatile var awaiting: Awaiting? = null

    /** Set by MainActivity so contacts permission can be requested the first time a name is used. */
    @Volatile var requestContacts: (() -> Unit)? = null

    val tts: TtsEngine by lazy { TtsEngine(app) }

    fun init(a: Application) {
        app = a
        keys = SecureKeyStore(a)
        settings = AppSettings(a)
        gemini = GeminiClient(keys)
        memory = MemoryRepo(a, scope)
        chat = ChatSession("chat")
        coding = ChatSession("coding")
        call = CallController(a, scope)
    }

    fun toast(msg: String) = Toast.makeText(app, msg, Toast.LENGTH_LONG).show()

    fun setMood(m: String) { mood.value = m }

    // ───────────── conversational confirmation (replaces popups) ─────────────

    /** Remember what to do after the user says yes, and return the question to ask. */
    fun confirmThen(prompt: String, run: () -> String): ToolOut {
        awaiting = Awaiting(prompt, System.currentTimeMillis() + 120_000, run)
        return ToolOut(prompt, ask = true)
    }

    /**
     * Chat and fallback-voice call this with every user sentence BEFORE sending it to Gemini.
     * Returns the result text if the sentence answered a pending question, otherwise null.
     */
    fun interceptAnswer(text: String): String? {
        val w = awaiting ?: return null
        if (System.currentTimeMillis() > w.expiresAt) { awaiting = null; return null }
        return when (Answer.parse(text)) {
            Answer.YES -> { awaiting = null; w.action() }
            Answer.NO -> { awaiting = null; "Theek hai, cancel kar diya. Kuch nahi kiya." }
            Answer.UNSURE -> { awaiting = null; null }
        }
    }

    private fun confirmPending(args: JSONObject): ToolOut {
        val w = awaiting ?: return ToolOut("Nothing is waiting for confirmation.")
        if (System.currentTimeMillis() > w.expiresAt) { awaiting = null; return ToolOut("That question expired. Ask again if still needed.") }
        val accepted = args.optBoolean("accepted", false)
        val said = Answer.parse(lastUserText)
        if (accepted && said != Answer.YES) {
            return ToolOut("The user has NOT clearly said yes. Do nothing. Ask again and wait for a clear 'haan' or 'yes'.")
        }
        awaiting = null
        return if (!accepted || said == Answer.NO) ToolOut("Cancelled. Nothing was done.") else ToolOut(w.action())
    }

    // ───────────── tools coming from Gemini ─────────────

    fun handleCall(name: String, args: JSONObject): ToolOut = when (name) {
        "remember" -> remember(args)
        "phone_action" -> phone(args)
        "send_message" -> Messaging.request(args)
        "confirm_pending" -> confirmPending(args)
        "screen_action" -> ScreenControl.run(args).also { log.value = it.text }
        else -> ToolOut("Unknown tool: $name")
    }

    private fun remember(args: JSONObject): ToolOut {
        val fact = args.optString("fact").trim()
        if (fact.isBlank()) return ToolOut("Nothing to remember.")
        val warn = if (MemoryRepo.looksSensitive(fact)) "Ye sensitive lag raha hai, phir bhi " else ""
        return confirmThen("${warn}Kya main ye yaad rakh loon: \"$fact\"? (haan / nahi)") {
            memory.add("fact", fact)
            "Theek hai, memory me save kar liya."
        }
    }

    private fun phone(args: JSONObject): ToolOut {
        val act = args.optString("action")
        if (Actions.needsConfirm(act)) {
            return confirmThen(Actions.describe(args)) {
                val r = Actions.run(app, args)
                log.value = r
                r
            }
        }
        val r = Actions.run(app, args)
        log.value = r
        return ToolOut(r)
    }

    /** Used by the Phone Automation screen: natural-language command -> tool calls. */
    suspend fun command(text: String): String {
        lastUserText = text
        interceptAnswer(text)?.let { return it }
        val s = settings
        return try {
            val r = gemini.generate(
                s.model, Persona.system("chat"), listOf(ChatMsg("user", text)),
                0.2, tools = Persona.tools
            )
            if (r.calls.isEmpty()) {
                Mood.strip(r.text).ifBlank { "I did not find an action to run." }
            } else {
                r.calls.joinToString("\n") { handleCall(it.name, it.args).text }
            }
        } catch (e: GeminiException) {
            e.message ?: "Error"
        }
    }
}
