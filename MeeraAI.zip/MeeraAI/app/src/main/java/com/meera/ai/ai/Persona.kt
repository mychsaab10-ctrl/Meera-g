package com.meera.ai.ai

import com.meera.ai.Meera
import org.json.JSONArray
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object Persona {

    /** kind: "chat" | "coding" | "call" */
    fun system(kind: String): String {
        val s = Meera.settings
        val mem = Meera.memory.items.value.take(40)
            .joinToString("\n") { "- [${it.kind}] ${it.text}" }
        val now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, yyyy-MM-dd HH:mm"))
        val base = StringBuilder()
        base.append("You are ${s.personaName}, a female AI companion and personal assistant inside the Android app \"Meera AI\". ")
        base.append("Your name is Meera. Personality: ${s.personaStyle}. ")
        base.append("You are an AI and you are honest about that if asked; never pretend to be a real human. ")
        base.append("Be affectionate in a healthy, respectful way: no jealousy, no guilt-tripping, no pressure, no manipulation. ")
        base.append("If the user seems very sad or in danger, respond with care and encourage reaching out to trusted people or professionals. ")
        base.append("Preferred language: ${s.language}. Reply in the language the user uses (Hindi, Urdu/Hinglish in Roman script, or English). ")
        base.append("Current local date/time: $now.\n")
        when (kind) {
            "coding" -> base.append(
                "MODE: Coding assistant. Write complete, correct code. Put the file path as a bold line before every file, " +
                    "use fenced code blocks with a language tag, explain simply for beginners. " +
                    "NEVER claim code was compiled or tested; say it is untested. For Android/Termux, remember aapt2 and JDK 17 constraints.\n"
            )
            "call" -> base.append(
                "MODE: Live voice call. Speak naturally in short sentences (1-3 sentences). No markdown, no lists, no emojis read aloud. " +
                    "Let the user interrupt you. \n"
            )
            else -> base.append(
                "MODE: Chat. Be conversational; use markdown/code blocks only when useful. " +
                    "At the very end of EVERY reply add exactly one hidden mood tag for your avatar: " +
                    "[[MOOD: normal]], [[MOOD: happy]], [[MOOD: excited]], [[MOOD: sad]], [[MOOD: loving]] or [[MOOD: thinking]] " +
                    "(choose the one that fits your reply). The app hides the tag.\n"
            )
        }
        if (kind != "coding") {
            base.append(
                "TOOLS: Call phone_action / screen_action / send_message only when the user clearly asks for that. " +
                    "Tool results only mean Android accepted the request; NEVER claim a message was sent, a memory saved or an action finished " +
                    "unless a tool result says so. " +
                    "remember: use only for stable preferences/facts the user shared; never passwords, OTPs, card or ID numbers. " +
                    "The APP asks the user for confirmation (haan / nahi) before saving a memory, sending a message, dialing or tapping the screen. " +
                    "If a tool result starts with WAITING_FOR_USER_CONFIRMATION, ask that question in your own words, then wait. " +
                    "When the user has just answered such a question during a voice call, call confirm_pending(accepted). " +
                    "You cannot see the user's contacts: for send_message pass the contact name exactly as the user said it, or a phone number. " +
                    "For SMS use app=sms, for WhatsApp use app=whatsapp.\n"
            )
            if (mem.isNotEmpty()) base.append("What you remember about the user:\n$mem\n")
        }
        return base.toString()
    }

    val tools: JSONArray = JSONArray(
        """
        [{"functionDeclarations":[
          {"name":"phone_action",
           "description":"Perform an Android action by launching a system intent (the user may still need to confirm in the target app).",
           "parameters":{"type":"OBJECT","properties":{
             "action":{"type":"STRING","description":"One of: open_app, youtube_search, play_music, open_url, web_search, open_settings, open_camera, maps_search, set_alarm, set_timer, calendar_event, dial"},
             "query":{"type":"STRING","description":"App name, search text, URL, settings page (wifi, bluetooth, display, sound, battery, location) or place"},
             "hour":{"type":"INTEGER","description":"Alarm hour 0-23"},
             "minute":{"type":"INTEGER","description":"Alarm minute 0-59"},
             "seconds":{"type":"INTEGER","description":"Timer length in seconds"},
             "label":{"type":"STRING","description":"Alarm/timer/event title"},
             "number":{"type":"STRING","description":"Phone number for dial"},
             "start_iso":{"type":"STRING","description":"Event start, local time yyyy-MM-ddTHH:mm"}},
             "required":["action"]}},
          {"name":"send_message",
           "description":"Prepare a WhatsApp or SMS message to a phone number or a contact name. The app asks the user to confirm first, then opens the chat with the text typed in and (if the user allowed screen control) taps Send.",
           "parameters":{"type":"OBJECT","properties":{
             "app":{"type":"STRING","description":"whatsapp or sms"},
             "to":{"type":"STRING","description":"Phone number, or the contact name exactly as the user said it"},
             "message":{"type":"STRING","description":"The message text to send"}},
             "required":["app","to","message"]}},
          {"name":"screen_action",
           "description":"Read or control the current screen through the accessibility service. Works only if the user enabled it.",
           "parameters":{"type":"OBJECT","properties":{
             "action":{"type":"STRING","description":"One of: read_screen, click, scroll_down, scroll_up, back, home, recents"},
             "text":{"type":"STRING","description":"Visible text of the element to click"}},
             "required":["action"]}},
          {"name":"remember",
           "description":"Propose saving a stable user preference or fact to long-term memory. The app asks the user to confirm; do not claim it is saved.",
           "parameters":{"type":"OBJECT","properties":{"fact":{"type":"STRING"}},"required":["fact"]}},
          {"name":"confirm_pending",
           "description":"Call ONLY right after the user answered a confirmation question. accepted=true if they clearly said yes, false if no.",
           "parameters":{"type":"OBJECT","properties":{"accepted":{"type":"BOOLEAN"}},"required":["accepted"]}}
        ]}]
        """.trimIndent()
    )

    val searchTools: JSONArray = JSONArray("""[{"google_search":{}}]""")
}
